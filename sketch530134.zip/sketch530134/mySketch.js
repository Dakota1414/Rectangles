function setup() {
	createCanvas(windowWidth, windowHeight);
	background(255,255,255);

}

function draw() {
strokeWeight(3)
stroke(2,2,2);
fill(142, 135, 138)
rect(40,40,40,20)
fill(255,255,255)
rect(80,40,50,20)
fill(249, 249, 0)
rect(130,40,60,20)
fill(255,255,255)
rect(190,40,20,110)
fill(255,255,255)
rect(40,60,30,30)
fill(249, 0, 0)
rect(70,60,60,70)
fill(249, 249, 0)
rect(130,60,60,30)
fill(255,255,255)
rect(40,90,30,70)
fill(255,255,255)
rect(130,90,30,40)
rect(160,90,30,40)
fill(2,2,2)
rect(70,130,40,40)
fill(177, 186, 201)
rect(110,130,20,20)
rect(110,150,20,20)
fill(255,255,255)
rect(130,130,60,20)
fill(237, 237, 2)
rect(40,160,30,40)
fill(255,255,255)
rect(70,170,40,30)
rect(110,180,80,20)
fill(2,2,2)
rect(110,170,20,10)
fill(6, 16, 204)
rect(130,150,60,30)
fill(214, 6, 6)
rect(190,150,20,50)
}